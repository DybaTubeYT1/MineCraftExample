# MineCraft Example

This is a simple MineCraft Example. You can see
[obiwac's Tutorial](https://www.youtube.com/playlist?list=PL6_bLxRDFzoKjaa3qCGkwR5L_ouSreaVP)
to learn how to use it